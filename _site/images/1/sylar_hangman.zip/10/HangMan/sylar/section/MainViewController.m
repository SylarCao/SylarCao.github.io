//
//  MainViewController.m
//  HangMan
//
//  Created by SylarCao on 3/9/15.
//  Copyright (c) 2015 SylarCao. All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////////////////
#import "MainViewController.h"
#import "Service.h"
#import "MBProgressHUD.h"
////////////////////////////////////////////////////////////////////////////////////////////
@interface MainViewController ()
<UITextFieldDelegate>

//@property (nonatomic, weak) IBOutlet UIButton *btnGuess;
//@property (nonatomic, weak) IBOutlet UIButton *btnStartGame;
//@property (nonatomic, weak) IBOutlet UIButton *btnGiveMeWord;
//@property (nonatomic, weak) IBOutlet UIButton *btnViewResult;
//@property (nonatomic, weak) IBOutlet UIButton *btnSubmit;

@property (nonatomic, weak) IBOutlet UITextView *feedbackContent;
@property (nonatomic, weak) IBOutlet UITextField *textInput;

@property (nonatomic, weak) IBOutlet UIImageView *imgHangMan;
@property (nonatomic, weak) IBOutlet UILabel *lbWord;

@property (nonatomic, strong) MBProgressHUD *hud;

@end
////////////////////////////////////////////////////////////////////////////////////////////
@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // textview layer
    _feedbackContent.layer.borderColor = [UIColor blackColor].CGColor;
    _feedbackContent.layer.borderWidth = 1;
    
    
    // tap view gesture
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapView)];
    [self.view addGestureRecognizer:tap];
    
    
    // hud
    _hud = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:_hud];
    
    // start
    _feedbackContent.text = @"click startGame to start the game.";
}

- (void) tapView
{
    [_textInput resignFirstResponder];
}

- (BOOL) correctWord:(NSString *)aWord
{
    BOOL rt = NO;
    if ([aWord rangeOfString:@"*"].location == NSNotFound)
    {
        rt = YES;
    }
    return rt;
}

#pragma mark - button
- (IBAction)btnGuess:(id)sender
{
    [self showHud];
    [_textInput resignFirstResponder];
    NSString *guess_word = [_textInput.text uppercaseString];
    if (guess_word.length == 1)
    {
        [[Service share] makeAGuess:guess_word block:^(BOOL success, NSDictionary *data) {
            if (success)
            {
                if ([[data objectForKey:@"message"] isEqualToString:@"No more guess left."])
                {
                    // 10 times failed
                    [self showHudWithTitle:@"No more guess left."];
                }
                else if ([[data objectForKey:@"message"] isEqualToString:@"You are not following the game flow"])
                {
                    [self showHudWithTitle:@"You are not following the game flow"];
                }
                else
                {
                    [self hideHud];
                    
                    // image
                    NSString *wrong_times = [[data objectForKey:@"data"] stringObjectForKey:@"wrongGuessCountOfCurrentWord"];
                    [self setWithImageHangStep:wrong_times];
                    
                    // word
                    NSString *the_word = [[data objectForKey:@"data"] objectForKey:@"word"];
                    _lbWord.text = the_word;
                    
                    // check word is correct
                    if ([self correctWord:the_word])
                    {
                        _feedbackContent.text = @"please GiveMeAWord to continue...";
                    }
                    else
                    {
                        // show the wrong time
                        _feedbackContent.text = [NSString stringWithFormat:@"wrongGuessCountOfCurrentWord = %@", wrong_times];
                    }
                }
            }
            else
            {
                [self showHudFail];
            }
        }];
    }
    else
    {
        [self showHudWithTitle:@"invalid word"];
    }
}

- (IBAction)btnStartGame:(id)sender
{
    [self showHud];
    [[Service share] startGame:^(BOOL success, NSDictionary *data) {
        if (success)
        {
            [self showHudWithTitle:@"Game Start"];
            _feedbackContent.text = @"game start, please press \"GiveMeAWord\"";
            
            // image
            [self setWithImageHangStep:@"0"];
        }
        else
        {
            [self showHudFail];
        }
    }];
}

- (IBAction)btnGiveMeWord:(id)sender
{
    [self showHud];
    [[Service share] giveMeAWord:^(BOOL success, NSDictionary *data) {
        if (success)
        {
            [self hideHud];
            
            // word
            NSString *word = [[data objectForKey:@"data"] objectForKey:@"word"];
            _lbWord.text = word;
            
            // image
            [self setWithImageHangStep:@"0"];
            
            // feed back
            _feedbackContent.text = @"please type a word to guess";
        }
        else
        {
            [self showHudFail];
        }
    }];
}

- (IBAction)btnViewResult:(id)sender
{
    [[Service share] getResult:^(BOOL success, NSDictionary *data) {
        if (success)
        {
            [self hideHud];
            NSString *score = [[data objectForKey:@"data"] stringObjectForKey:@"score"];
            NSString *correctWordCount = [[data objectForKey:@"data"] stringObjectForKey:@"correctWordCount"];
            NSString *totalWordCount = [[data objectForKey:@"data"] stringObjectForKey:@"totalWordCount"];
            NSString *totalWrongGuessCount = [[data objectForKey:@"data"] stringObjectForKey:@"totalWrongGuessCount"];
            _feedbackContent.text = [NSString stringWithFormat:@"score = %@ \n\ntotalWordCount = %@ \ncorrectWordCount = %@ \ntotalWrongGuessCount = %@", score, totalWordCount, correctWordCount, totalWrongGuessCount];
        }
        else
        {
            [self showHudFail];
        }
    }];
}

- (IBAction)btnSubmit:(id)sender
{
    [[Service share] submitResult:^(BOOL success, NSDictionary *data) {
        if (success)
        {
            if ([[data objectForKey:@"message"] isEqualToString:@"Game already over"])
            {
                [self showHudWithTitle:@"Game already over"];
            }
            else
            {
                [self hideHud];
                _feedbackContent.text = @"Game Over";
            }
        }
        else
        {
            [self showHudFail];
        }
    }];
}

#pragma mark - hud
- (void) hideHud
{
    [_hud hide:YES];
}

- (void) showHud
{
    _hud.mode = MBProgressHUDModeIndeterminate;
    _hud.labelText = nil;
    
    [_hud show:YES];
}

- (void) showHudFail
{
    [self showHudWithTitle:@"request failed"];
}

- (void) showHudWithTitle:(NSString *)title
{
    _hud.mode = MBProgressHUDModeText;
    _hud.labelText = title;
    [_hud showAnimated:YES whileExecutingBlock:^{
        sleep(1);
    } completionBlock:^{
        _hud.mode = MBProgressHUDModeIndeterminate;
    }];
}

#pragma mark - input delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.text = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - image
- (void) setWithImageHangStep:(NSString *)step
{
    NSString *name = [NSString stringWithFormat:@"img_hang_%@", step];
    UIImage *aImage = [UIImage imageNamed:name];
    _imgHangMan.image = aImage;
    
    if ([step isEqualToString:@"10"])
    {
        _feedbackContent.text = @"no more time to guess  \nplease click GiveMeAWord";
    }
}

@end
