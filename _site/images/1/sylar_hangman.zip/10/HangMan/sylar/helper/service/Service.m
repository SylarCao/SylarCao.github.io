//
//  Service.m
//  HangMan
//
//  Created by SylarCao on 3/9/15.
//  Copyright (c) 2015 SylarCao. All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////////////////
#import "Service.h"
#import "AFNetworking.h"
#import "JSONKit.h"
////////////////////////////////////////////////////////////////////////////////////////////
# define kMyId @"1579917501@qq.com"
# define kUrl @"https://strikingly-hangman.herokuapp.com/game/on"
////////////////////////////////////////////////////////////////////////////////////////////
@interface Service()

@property (nonatomic, strong) NSString *sessionId;

@property (nonatomic, strong) cbServiceBlock block;
@property (nonatomic, assign) BOOL start;

@end
////////////////////////////////////////////////////////////////////////////////////////////
@implementation Service

+ (instancetype) share
{
    static Service *inst = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        inst = [[Service alloc] init];
    });
    return inst;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        _start = YES;
    }
    return self;
}

- (void) startGame:(cbServiceBlock)block
{
    _block = block;
    _start = YES;
//    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:
                          kMyId, @"playerId",
                          @"startGame", @"action",
                          nil];

//    [manager POST:kUrl parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"");
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"");
//    }];
    
    
    NSURL *url = [[NSURL alloc] initWithString:kUrl];
    NSMutableURLRequest *rr = [[NSMutableURLRequest alloc] initWithURL:url];
    [rr setHTTPMethod:@"POST"];
    [rr setHTTPBody:[dict JSONData]];
    [NSURLConnection connectionWithRequest:rr delegate:self];

}

- (void) giveMeAWord:(cbServiceBlock)block
{
    _block = block;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:
                          _sessionId, @"sessionId",
                          @"nextWord", @"action",
                          nil];
    NSURL *url = [[NSURL alloc] initWithString:kUrl];
    NSMutableURLRequest *rr = [[NSMutableURLRequest alloc] initWithURL:url];
    [rr setHTTPMethod:@"POST"];
    [rr setHTTPBody:[dict JSONData]];
    [NSURLConnection connectionWithRequest:rr delegate:self];
}

- (void) makeAGuess:(NSString *)guessWord block:(cbServiceBlock)block
{
    _block = block;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:
                          _sessionId, @"sessionId",
                          @"guessWord", @"action",
                          guessWord, @"guess",
                          nil];
    NSURL *url = [[NSURL alloc] initWithString:kUrl];
    NSMutableURLRequest *rr = [[NSMutableURLRequest alloc] initWithURL:url];
    [rr setHTTPMethod:@"POST"];
    [rr setHTTPBody:[dict JSONData]];
    [NSURLConnection connectionWithRequest:rr delegate:self];
}

- (void) getResult:(cbServiceBlock)block
{
    _block = block;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:
                          _sessionId, @"sessionId",
                          @"getResult", @"action",
                          nil];
    NSURL *url = [[NSURL alloc] initWithString:kUrl];
    NSMutableURLRequest *rr = [[NSMutableURLRequest alloc] initWithURL:url];
    [rr setHTTPMethod:@"POST"];
    [rr setHTTPBody:[dict JSONData]];
    [NSURLConnection connectionWithRequest:rr delegate:self];
}

- (void) submitResult:(cbServiceBlock)block
{
    _block = block;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:
                          _sessionId, @"sessionId",
                          @"submitResult", @"action",
                          nil];
    NSURL *url = [[NSURL alloc] initWithString:kUrl];
    NSMutableURLRequest *rr = [[NSMutableURLRequest alloc] initWithURL:url];
    [rr setHTTPMethod:@"POST"];
    [rr setHTTPBody:[dict JSONData]];
    [NSURLConnection connectionWithRequest:rr delegate:self];
}


#pragma mark - delegate
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSDictionary *dict = [data objectFromJSONData];
    NSLog(@"response  = %@", dict);
    if ([[dict objectForKey:@"message"] isEqualToString:@"Missing action"])
    {
        if (_block)
        {
            _block(NO, nil);
        }
    }
    else
    {
        if (_start)
        {
            _sessionId = [dict objectForKey:@"sessionId"];
            _start = NO;
        }
        if (_block)
        {
            _block (YES, dict);
        }
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    if (_block)
    {
        _block(NO, nil);
    }
}

@end

@implementation NSDictionary(stringNumber)

- (NSString *) stringObjectForKey:(NSString *)key
{
    NSString *rt = nil;
    NSString *value = [self objectForKey:key];
    if ([value isKindOfClass:[NSNumber class]])
    {
        rt = [NSString stringWithFormat:@"%d", [value integerValue]];
    }
    else
    {
        return rt;
    }
    return rt;
}

@end
