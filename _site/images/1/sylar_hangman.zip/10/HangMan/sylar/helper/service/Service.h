//
//  Service.h
//  HangMan
//
//  Created by SylarCao on 3/9/15.
//  Copyright (c) 2015 SylarCao. All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////////////////
#import <Foundation/Foundation.h>
////////////////////////////////////////////////////////////////////////////////////////////
typedef void (^cbServiceBlock)(BOOL success, NSDictionary *data);
////////////////////////////////////////////////////////////////////////////////////////////
@interface Service : NSObject


+ (instancetype) share;

- (void) startGame:(cbServiceBlock)block;

- (void) giveMeAWord:(cbServiceBlock)block;

- (void) makeAGuess:(NSString *)guessWord block:(cbServiceBlock)block;

- (void) getResult:(cbServiceBlock)block;

- (void) submitResult:(cbServiceBlock)block;

@end
////////////////////////////////////////////////////////////////////////////////////////////

@interface NSDictionary(stringNumber)

- (NSString *) stringObjectForKey:(NSString *)key;

@end

