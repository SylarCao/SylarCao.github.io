no cool things.


Those undetermined requirements such as UI design and error message processing are not list in the website.
I just manage them on my own.

And I have a concern that why I can't access to the request url via AFNetworking.